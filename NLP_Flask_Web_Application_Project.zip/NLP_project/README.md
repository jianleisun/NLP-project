# NLP-project
Sentimental Analysis for Amazon Book Reviews
