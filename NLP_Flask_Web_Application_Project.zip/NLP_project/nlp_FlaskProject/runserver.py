# applicaiton entry, 3/23/2017
from review import app
app.run()
