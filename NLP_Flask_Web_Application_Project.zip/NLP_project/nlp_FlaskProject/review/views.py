from . import app
from .forms import FeatureForm

from flask import render_template
from .model.review import ReviewModel

@app.route('/')
def index():
    return render_template('welcome.html')


@app.route('/form/', methods=('GET', 'POST'))
def form():
    myform = FeatureForm()
    if myform.is_submitted():
        line = myform.review_text.data
        review_model = ReviewModel()
        sentiment, highlight_words = review_model.predict(line)
        return render_template('result.html', line=line, highlight_words=highlight_words,
                               sentiment=sentiment)

    return render_template('form.html', form=myform)

# show pos or neg; highlight the text
@app.route('/result/')
def submit():
    return render_template('result.html')


@app.route('/about')
def about():
    return 'Natural Language Processing (NLP) - Sentimental Analysis for Amazon Book Reviews'


@app.route('/author')
def author():
    return 'Jianlei (John) Sun'
