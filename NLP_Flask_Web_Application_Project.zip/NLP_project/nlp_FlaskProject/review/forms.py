from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField


class FeatureForm(FlaskForm):
    review_text = StringField('Please Enter the Review Text:')
    go = SubmitField('Submit')
