# creak Flask object
from flask import Flask
app = Flask(__name__)

# web applicaiotn settings
app.config.from_pyfile('default_config.py')

# import the web pages from views
from review import views
