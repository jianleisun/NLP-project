import string
import nltk
from nltk.corpus import stopwords
import pickle

class BaseModel:
    def __init__(self):
        self.lemmatizer = nltk.WordNetLemmatizer()
        self.stop = stopwords.words('english')
        self.translation = str.maketrans(string.punctuation, ' ' * len(string.punctuation))

        self.model = None
        self.vec = None

    # load the vectorizer
    def load_vec(self, vec_path, mode='rb'):
        with open(vec_path, mode) as pkl_file:
            self.vec = pickle.load(pkl_file)

    # load the model
    def load_model(self, model_path, mode='rb'):
        with open(model_path, mode) as pkl_file:
            self.model = pickle.load(pkl_file)

    # Preprocessing
    def preprocessing(self, line):

            tokens = []
            line = str(line).translate(self.translation)  # Replace punctuation
            line = nltk.word_tokenize(line.lower())  # Tokenize

            for t in line:
                # Remove stopwords
                if t not in self.stop:
                    stemmed = self.lemmatizer.lemmatize(t)  # deal with nouns
                    stemmed = self.lemmatizer.lemmatize(stemmed, 'v')  # deal with verbs
                    tokens.append(stemmed)

            return ' '.join(tokens)

    # Predict
    def predict(self, line):
        if self.model or self.vec is None:
            print("Model/Vectorizer is not loaded")

        line = self.preprocessing(line)
        features = self.vec.transform([line])

        return self.model.predict(features)[0]











