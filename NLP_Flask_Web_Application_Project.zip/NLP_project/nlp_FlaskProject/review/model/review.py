from .base import BaseModel

class ReviewModel(BaseModel):
    def __init__(self):
        # initialize BaseModel => self.
        # python 3 compatitable
        super().__init__()

        # from root directory
        self.load_model('models/mnb_model.pkl')
        self.load_vec('models/tf_vec.pkl')

    # if derived class is different from base class, overide the base class
    def predict(self, line, highlight=True):
        sentiment = super(ReviewModel, self).predict(line)
        if highlight:
            highlight_words = [w for w in self.preprocessing(line).split()
                               if super(ReviewModel, self).predict(w) == sentiment]
            return sentiment, highlight_words
        else:
            return sentiment




